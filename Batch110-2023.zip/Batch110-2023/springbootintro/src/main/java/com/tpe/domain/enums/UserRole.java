package com.tpe.domain.enums;

public enum UserRole {
    ROLE_STUDENT,
    ROLE_ADMIN
}
