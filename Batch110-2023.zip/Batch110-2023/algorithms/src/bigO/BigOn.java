package bigO;

public class BigOn {
    public static void main(String[] args) {

        //print each element on the console
        int [] arr= {4, 6, 8, 9, 0, 4, 1, 5, 7};
        for(int el: arr){
            System.out.println(el);
        }

    }
}
