package bigO;

public class BigO1 {
    public static void main(String[] args) {
        //print last element of the arryar
        int [] arr= {4, 6, 8, 9, 0, 4, 1};
        System.out.println(arr.length-1);

        //task: check if the given number is even or odd
        int x = 34;
        if(x%2==0) System.out.println("even");
    }
}
