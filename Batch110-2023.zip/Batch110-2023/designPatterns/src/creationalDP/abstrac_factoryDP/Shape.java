package creationalDP.abstrac_factoryDP;

public interface Shape {
    void draw();
}
