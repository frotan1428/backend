package creationalDP.abstrac_factoryDP;

public class Green implements Color{
    @Override
    public void fill() {
        System.out.println("Filled with green color");
    }
}
