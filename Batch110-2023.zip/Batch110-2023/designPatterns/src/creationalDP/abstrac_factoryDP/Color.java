package creationalDP.abstrac_factoryDP;

public interface Color {
    void fill();
}
