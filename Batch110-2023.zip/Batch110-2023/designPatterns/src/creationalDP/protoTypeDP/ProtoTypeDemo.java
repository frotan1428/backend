package creationalDP.protoTypeDP;

public class ProtoTypeDemo {
    public static void main(String[] args) {
        Soldier availableSoldier = new Soldier(100, 45, 20,
                30, 10, 30, "Sward", true);

        //********* bad scenario **********
        //i need to set all the fields except for the last field to be able to creeate soldier who is not able to fight
        Soldier notAvailableSoldier1 = new Soldier(100, 45, 20,
                30, 10, 30, "Sward", false);




        Soldier availableSoldier2 = new Soldier(100, 45, 20,
                30, 20, 30, "Sward", true);

        //********* end bad scenario **********


        //********* use clone **********

        Soldier noAvailableSoldier2 = availableSoldier.clone();
        noAvailableSoldier2.setAvailableForWar(false);


        notAvailableSoldier1.showSoldierInfo();
        System.out.println("*************");
        noAvailableSoldier2.showSoldierInfo();

    }
}
