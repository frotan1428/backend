package creationalDP.factoryDP;

public interface Shape {
    void draw();
}
