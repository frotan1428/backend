package structuralDP.facadeDP;

public class MD5Encryptor {

    public void encrypt(String text, String security){
        System.out.println("<MD5>" + text + security+ "<MD5>");
    }

}
