package structuralDP.facadeDP;

public class AESEncryptor {
    public void encrypt(String text){
        System.out.println("<AES>" + text + "<AES>");
    }
}
