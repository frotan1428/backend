package structuralDP.decoratorDP;

public class DecoratorRunner {
    public static void main(String[] args) {

        Phone iPhone11ProMax= new IPhone11ProMax(new IPhone());
        System.out.println("Name: "+iPhone11ProMax.getName());
        System.out.println("Number of camera: "+iPhone11ProMax.cameraCount());
        System.out.println("Price: "+iPhone11ProMax.getPrice());


        //task

    }
}
