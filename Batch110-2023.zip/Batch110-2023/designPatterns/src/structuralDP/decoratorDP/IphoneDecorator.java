package structuralDP.decoratorDP;

public class IphoneDecorator implements Phone{

    protected Phone basicPhone;

    //constructor


    public IphoneDecorator(IPhone basicPhone) {
        this.basicPhone = basicPhone;
    }

    @Override
    public String getName() {
        return basicPhone.getName();  //IPhone
    }

    @Override
    public int cameraCount() {
        return basicPhone.cameraCount(); //2
    }

    @Override
    public double getPrice() {
        return basicPhone.getPrice(); //599.9
    }
}
