package structuralDP.decoratorDP;

public class IPhone11 extends IphoneDecorator{


    public IPhone11(IPhone basicPhone) {
        super(basicPhone);
    }

    @Override
    public String getName() {
        return super.getName()+"11";
    }

    //if iphone 11 has 2 cameras
    //
}
