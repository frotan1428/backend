package structuralDP.proxyDP;

public class ProxyRunner {
    public static void main(String[] args) {

        ImageGenerator proxyClaas1 = new ImageProxyClass("c:\\image1.png");
        ImageGenerator proxyClaas2 = new ImageProxyClass("c:\\image2.png");


        proxyClaas1.showImageName();
        proxyClaas2.showImageName();

    }
}
