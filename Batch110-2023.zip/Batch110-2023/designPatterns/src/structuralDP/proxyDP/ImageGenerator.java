package structuralDP.proxyDP;

public interface ImageGenerator {
    void showImageName();
}
