package structuralDP.compositeDP;

import java.util.List;
import java.util.stream.Collectors;

public class HRDepartment extends Department{

    List<Department> childDepartments;

    //constructor
    public HRDepartment(List<Department> childDepartments) {
        this.childDepartments = childDepartments;
    }

    @Override
    String getName() {
        return childDepartments.stream(). //Finance obj and Sales obj
                map(Department::getName). //"Finance", "Sales"
                collect(Collectors.joining(", ")); //"Finance, Sales"
    }

    @Override
    //flapMap() = map()+flattening
    List<String> getEmployee() {
        return childDepartments.stream().
                flatMap(d->d.getEmployee().
                        stream()).collect(Collectors.toList());
    }
}
