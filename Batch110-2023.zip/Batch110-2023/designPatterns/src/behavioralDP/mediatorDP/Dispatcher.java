package behavioralDP.mediatorDP;

public interface Dispatcher {
    void dispatch(String topic, String message);
}
