package behavioralDP.observerDP;

public interface Channel {

    void update(String news);

    void printNews();

}
