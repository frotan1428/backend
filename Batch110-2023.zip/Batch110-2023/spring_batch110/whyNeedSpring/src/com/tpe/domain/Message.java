package com.tpe.domain;

public class Message {
    private String message;

    //Getter- Setter

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
