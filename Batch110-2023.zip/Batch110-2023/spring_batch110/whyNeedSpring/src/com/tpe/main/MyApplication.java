package com.tpe.main;

import com.tpe.domain.Message;
import com.tpe.service.MailService;
import com.tpe.service.MessageService;
import com.tpe.service.SmsService;
import com.tpe.service.WhatsAppService;

public class MyApplication {
    public static void main(String[] args) {

        //creating obj and setting message
        //========= Level 1 starts ===========
        Message message = new Message();
        message.setMessage("Orders have been submitted to cargo...");

        //creating obj from MailService, sending message via mailservice
//        MailService mailService = new MailService();
//
//        mailService.sendMessage(message);
//
//
//        SmsService smsService = new SmsService();
//        smsService.sendMessage(message);
//
//
//        WhatsAppService whatsAppService = new WhatsAppService();
//        whatsAppService.sendMessage(message);

        //========= Level 1 ends ===========
        //========= Level 2 starts ===========
//        MessageService service = new WhatsAppService();
//        service.sendMessage(message);

//        MessageService whatService = new WhatsAppService();
//        whatService.sendMessage(message);
//
//        MessageService smsService = new SmsService();
//        smsService.sendMessage(message);

        //========= Level 2 ends ===========

        //========= Level 3 starts ===========

        String serviceName = "mailService";

        MessageService service;

        if(args.length>0){
            serviceName = args[0];
        }

        if(serviceName.equalsIgnoreCase("whatsAppService")){
            service  = new WhatsAppService();
        }else if(serviceName.equalsIgnoreCase("smsService")){
            service = new SmsService();
        }else {
            service = new MailService();
        }

        service.sendMessage(message);



    }
}
