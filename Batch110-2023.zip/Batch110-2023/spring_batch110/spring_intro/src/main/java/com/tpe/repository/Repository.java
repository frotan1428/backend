package com.tpe.repository;

import com.tpe.domain.Message;

public interface Repository {
    void saveMessage(Message message);
}
