package com.tpe.service;

import com.tpe.domain.Message;
import com.tpe.repository.FileRepository;
import com.tpe.repository.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("mailService") //instance of this class will be created, and waiting in IoC container
//@Scope(value = "singleton") //it is the default value
@Scope(value="prototype")
public class MailService implements MessageService{

    @Value("${app.email}")
    private String email;

    //Repository repository = new FileRepository();

    //Field Injetion
//    @Autowired
//    @Qualifier("dbRepository") // @Qualifier annotation is used after @Autowired, if
//    // there are more than one concrete child class
//    private Repository repository;


    //Setter Injection

//    private Repository repository;
//    @Autowired
//    @Qualifier("dbRepository")
//    public void setRepository(Repository repository) {
//        this.repository = repository;
//    }

    //Constructor Injection

    private Repository repository;

    @Autowired
    public MailService(@Qualifier("fileRepository") Repository repository) {
        this.repository = repository;
    }

    public void sendMessage(Message message){
        System.out.println("I am a Mail Service, and I am sending you this message:"+message.getMessage());

        repository.saveMessage(message);
        System.out.println(email);

    }
}
