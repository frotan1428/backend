package com.tpe.app;

import com.tpe.AppConfiguration;
import com.tpe.domain.Message;
import com.tpe.service.MailService;
import com.tpe.service.MessageService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.awt.*;

public class MyApplication {
    public static void main(String[] args) {
        Message message = new Message();
        message.setMessage("You orders have been received...");

        //indicating configuration class
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfiguration.class);


       // MailService service = context.getBean(MailService.class);

        MessageService service= context.getBean("mailService", MessageService.class);

        // let s check if we are using the same object
        MessageService service2 = context.getBean("mailService", MessageService.class);

        if(service2 == service){
            System.out.println("They are the same Object");
        }else {
            System.out.println("They are different object");
        }

        service.sendMessage(message);


        //call Point from container
        Point point = context.getBean("point", Point.class);
        System.out.println("X coordinate: "+point.getX());


        context.close();//life cycle of created beans will be ended

    }
}
