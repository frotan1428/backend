package day03;

import java.util.Arrays;

public class T01_CompareArrays {

    /*
        are there arrays are equal
            {3, 5, 1} vs {1, 3, 5}
            {"a", "j", "a", "v"} vs {"j", "a", "v", "a"}
     */

    public static boolean compareArraysEqual(Object[] a, Object[] b ){
        Arrays.sort(a);
        Arrays.sort(b);
        return Arrays.equals(a, b);
    }

}
