package day03;

public class T02_Mocking {

    public void saveStudent(String studentName){
        System.out.println("Student has been registered...");
    }

    public void deleteStudent(String studentName){
        System.out.println("Student has been deleted....");
    }

    public void updateStudent(String studentName){
        System.out.println("Student has been updated successfully");
    }

}
