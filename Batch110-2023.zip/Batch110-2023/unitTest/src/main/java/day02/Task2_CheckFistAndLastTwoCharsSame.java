package day02;

public class Task2_CheckFistAndLastTwoCharsSame {
    /*
            write a method which will compare last and first two characters are the same

                BABA --> true
                ACHJHJHAC-->true
                AAA --> true

                A --> false
                AB --> true

     */

    public boolean checkIfFirstAndLastTwoCharsEqual(String str){
        if(str.length()<=1) return false;
        if(str.length() ==2) return true; //

        String firstTwoChars = str.substring(0, 2);
        String lastTwoChars =  str.substring(str.length()-2);
        return firstTwoChars.equals(lastTwoChars);
    }

}
