package day02;

public class Task1_RemoveAFromFirstTwoChars {


    /*
    write a method which removes "A" from a String, if "A"
    is found in first 2 characters of the String

    Note: all characters will be in capital
        AABB  --> BB
        ABAB --> BAB
        AA -->
        BA -->B

     */

    public String deleteAIfItIsFoundInFirstTwoChars(String str){
        //check the length
        if(str.length()<=2) return str.replaceAll("A", "");

        // if the length is > 2
        String firstTwoChar = str.substring(0,2);
        String charsAfterFirstTwo = str.substring(2);

        return firstTwoChar.replaceAll("A", "") + charsAfterFirstTwo;
    }


}
