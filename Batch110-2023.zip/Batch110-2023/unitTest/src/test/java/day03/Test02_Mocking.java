package day03;

import org.junit.jupiter.api.*;
import org.mockito.InOrder;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;

@TestMethodOrder(MethodOrderer.class)
public class Test02_Mocking {
    //we will test how we can verify mocked class

    T02_Mocking dummyObj1;

    @BeforeEach
    void setUp() {
        dummyObj1 = Mockito.mock(T02_Mocking.class);
    }

    @Test
    @Order(3)
    void testMocking(){


        //these are mock obj not real

        dummyObj1.saveStudent("Ali");
        dummyObj1.deleteStudent("Mustafa");
        dummyObj1.updateStudent("Okan");

        //let s verify if they are real or not
        verify(dummyObj1).saveStudent("Ali");
        verify(dummyObj1).deleteStudent("Mustafa");
        verify(dummyObj1).updateStudent("Okan");
    }

    //verify how many times these methods are called
    @Test
    @Order(1)
    void testHowManyTimesMocksCalled(){
        dummyObj1.saveStudent("Mustafa");
        dummyObj1.saveStudent("Mustafa");
        dummyObj1.saveStudent("Ali");

        verify(dummyObj1, times(2)).saveStudent("Mustafa");
        verify(dummyObj1, times(1)).saveStudent("Ali");
        //to verify never called methods
        verify(dummyObj1, never()).updateStudent("Al");
        verify(dummyObj1, never()).updateStudent(anyString()); //to verify if the method is not called with any argument
        verify(dummyObj1, atLeast(2)).saveStudent("Mustafa"); //verify if the method called minimum twice

    }
    //very execution order of mock obj
    @Test
    @Order(2)
    void testControlOrderMethods(){
        dummyObj1.saveStudent("Mustafa");
        dummyObj1.deleteStudent("Mustafa");
        dummyObj1.saveStudent("Ali");

        InOrder inOrder = inOrder(dummyObj1);

        inOrder.verify(dummyObj1).saveStudent("Mustafa");
        inOrder.verify(dummyObj1).deleteStudent("Mustafa");
        inOrder.verify(dummyObj1).saveStudent("Ali");

    }
}
