package day01;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class Test06_DisplayName {

    //mehtod name should be understandable, if it is too long,or if
    // you need to explain in different way then you can @DisplayName()

    @DisplayName("Exception if Integer.parseInt() is not a integer")
    @Test
    void testException(){
        String str = "Hello1234";
        assertThrows(NumberFormatException.class, ()->{
            Integer.parseInt(str);
        });
    }

}
