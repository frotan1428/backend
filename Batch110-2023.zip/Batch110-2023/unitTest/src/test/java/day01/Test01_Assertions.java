package day01;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Test01_Assertions {
    /*
        Starting from Junit5, we do not need to write public access modifier.
        tetMethod name is suggested to start with "testNameOfMethod"
     */

    @Test
    public void test(){

    }

    //method to test length of sting
    @Test
    public void testLength(){
        String str = "Hello World";
        int actualValue = str.length();
        int expectedValue = 11;
        assertEquals(expectedValue, actualValue);
    }

    //test upperCase method from String class
    @Test
    public void testUpperCase(){
        String actualString = "hello".toUpperCase(); //HELLO
        String expectedString = "HELLO";
        assertEquals(expectedString, actualString, "upperCase method failed");

    }

    //testing Math.addExact()
    @Test
    void testSum(){
        int num1  = 10;
        int num2  = 13;
        int actualValue = Math.addExact(num1, num2);
        int expectedValue = 23;
        assertEquals(expectedValue, actualValue);
    }

    //we do not need to create separate variable

    //string.Contains()
    @Test
    void testContains(){
        assertEquals(false, "Java".contains("z"));
    }

}
