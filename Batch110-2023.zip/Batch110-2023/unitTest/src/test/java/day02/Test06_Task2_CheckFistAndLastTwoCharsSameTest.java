package day02;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

class Test06_Task2_CheckFistAndLastTwoCharsSameTest {

    Task2_CheckFistAndLastTwoCharsSame obj = new Task2_CheckFistAndLastTwoCharsSame();

    @ParameterizedTest
    @CsvSource(value = {"true, BABA", "true, AB", "false, A"})
    void checkIfFirstAndLastTwoCharsEqual(boolean expected, String str) {
        assertEquals(expected, obj.checkIfFirstAndLastTwoCharsEqual(str));
    }
    // the same test using @ValueSource

    @ParameterizedTest
    @ValueSource(strings = {"BABA", "AB"})
    void checkIfFirstAndLastTwoCharsEqual1(String str){
        assertTrue(obj.checkIfFirstAndLastTwoCharsEqual(str));
    }

    @ParameterizedTest
    @ValueSource(strings = {"B", "ABBABA"})
    void checkIfFirstAndLastTwoCharsEqual2(String str){
        assertFalse(obj.checkIfFirstAndLastTwoCharsEqual(str));
    }


}