package com.generics.genericInterface;

public class GenericInterfaceImpl02 implements GenericInterface<String>{
    @Override
    public void setValue(String s) {
    }

    @Override
    public String getValue() {
        return null;
    }
}
